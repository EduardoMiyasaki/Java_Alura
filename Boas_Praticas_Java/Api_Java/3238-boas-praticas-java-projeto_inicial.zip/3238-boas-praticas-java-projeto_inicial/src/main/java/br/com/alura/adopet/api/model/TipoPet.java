package br.com.alura.adopet.api.model;

public enum TipoPet {
    GATO,
    CACHORRO;
}
